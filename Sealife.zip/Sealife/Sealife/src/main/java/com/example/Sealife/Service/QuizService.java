package com.example.Sealife.Service;

import com.example.Sealife.domain.OceanAnimals;
import com.example.Sealife.domain.Option;
import com.example.Sealife.domain.Question;
import com.example.Sealife.domain.User;
import com.example.Sealife.domain.UserAnswer;
import com.example.Sealife.domain.UserQuizProgress;
import com.example.Sealife.repository.OceanAnimalsRepository;
import com.example.Sealife.repository.OptionRepository;
import com.example.Sealife.repository.QuestionRepository;
import com.example.Sealife.repository.UserAnswerRepository;
import com.example.Sealife.repository.UserQuizProgressRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class QuizService {

    private final OceanAnimalsRepository animalRepo;
    private final QuestionRepository questionRepo;
    private final OptionRepository optionRepo;
    private final UserQuizProgressRepository progressRepo;
    private final UserAnswerRepository answerRepo;

    public Question getNextQuestion(User user, Long animalId) {

        OceanAnimals animal = animalRepo.findById(animalId).orElseThrow();
        UserQuizProgress progress = progressRepo
                .findByUserAndAnimal(user, animal)
                .orElseGet(() -> createProgress(user, animal));

        if (progress.isCompleted()) return null;

        List<Question> questions = questionRepo.findByAnimalOrderByQuestionOrder(animal);
        return questions.get(progress.getCurrentQuestion());
    }

    // Save answer
    public void submitAnswer(User user, Long questionId, Long optionId) {

        Question question = questionRepo.findById(questionId).orElseThrow();
        Option selected = optionRepo.findById(optionId).orElseThrow();

        boolean correct = selected.isCorrect();

        UserAnswer answer = new UserAnswer();
        answer.setUser(user);
        answer.setQuestion(question);
        answer.setSelectedOption(selected);
        answer.setCorrect(correct);
        answerRepo.save(answer);

        updateProgress(user, question.getAnimal(), correct);
    }

    private void updateProgress(User user, OceanAnimals animal, boolean correct) {

        UserQuizProgress progress = progressRepo.findByUserAndAnimal(user, animal).orElseThrow();

        progress.setCurrentQuestion(progress.getCurrentQuestion() + 1);

        if (correct) progress.setScore(progress.getScore() + 1);

        if (progress.getCurrentQuestion() >= 10) {
            progress.setCompleted(true);
        }

        progressRepo.save(progress);
    }

    private UserQuizProgress createProgress(User user, OceanAnimals animal) {
        UserQuizProgress progress = new UserQuizProgress();
        progress.setUser(user);
        progress.setAnimal(animal);
        progress.setCurrentQuestion(0);
        progress.setCompleted(false);
        progress.setScore(0);
        return progressRepo.save(progress);
    }

//    public Question getNextQuestion(Long userId, String animalName) {
//
//        OceanAnimals animal = animalRepo.findByNameIgnoreCase(animalName)
//                .orElseThrow(() -> new RuntimeException("Animal not found"));
//
//        List<Question> questions = questionRepo.findByAnimalId(animal.getId());
//
//        UserQuizProgress progress = progressRepo
//                .findByUserIdAndAnimalId(userId, animal.getId())
//                .orElseGet(() -> {
//                    UserQuizProgress p = new UserQuizProgress();
//                    User user = new User();
//                    user.setId(userId);
//                    p.setUser(user);
//                    p.setAnimal(animal);
//                    p.setCurrentQuestion(0);
//                    return progressRepo.save(p);
//                });
//
//        if (progress.getCurrentQuestion() >= questions.size()) {
//            progress.setCompleted(true);
//            progressRepo.save(progress);
//            return null;
//        }
//
//        return questions.get(progress.getCurrentQuestion());
//    }
//
//    public void submitAnswer(Long userId, Long questionId, Long optionId) {
//        Option opt = optionRepo.findById(optionId).orElseThrow();
//        Question q = opt.getQuestion();
//
//        UserAnswer ans = new UserAnswer();
//        User user = new User();
//        user.setId(userId);
//        ans.setUser(user);;
//        ans.setQuestion(q);
//        ans.setSelectedOption(opt);
//        ans.setCorrect(opt.isCorrect());
//        answerRepo.save(ans);
//
//        UserQuizProgress progress = progressRepo
//                .findByUserIdAndAnimalId(userId, q.getAnimal().getId())
//                .orElseThrow();
//
//        progress.setCurrentQuestion(progress.getCurrentQuestion() + 1);
//        progressRepo.save(progress);
//    }
}
