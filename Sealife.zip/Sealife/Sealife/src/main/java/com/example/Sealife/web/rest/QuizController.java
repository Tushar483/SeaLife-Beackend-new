package com.example.Sealife.web.rest;

import com.example.Sealife.Service.QuizService;
import com.example.Sealife.config.security.CustomUserDetails;
import com.example.Sealife.domain.Option;
import com.example.Sealife.domain.Question;
import com.example.Sealife.domain.User;
import com.example.Sealife.dto.AnswerRequest;
import com.example.Sealife.dto.QuestionDto;
import com.example.Sealife.repository.OptionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.security.core.annotation.AuthenticationPrincipal;

import java.util.List;

@RestController
@RequestMapping("/api/quiz")
@RequiredArgsConstructor
public class QuizController {

    private final QuizService quizService;
    private final OptionRepository optionRepository;

    // Get next question for animal
//    @GetMapping("/{animal}")
//    public QuestionDto getQuestion(@PathVariable String animal,
//                                   @AuthenticationPrincipal UserDetails user) {
//
//        Long userId = ((CustomUserDetails) user).getId();
//        Question q = quizService.getNextQuestion(userId, animal);
//
//        if (q == null) return null;
//
//        List<Option> options = optionRepository.findByQuestionId(q.getId());
//
//        return QuestionDto.from(q, options);
//    }
//
//    // Submit answer
//    @PostMapping("/answer")
//    public ResponseEntity<?> submit(@RequestBody AnswerRequest req,
//                                    @AuthenticationPrincipal UserDetails user) {
//        Long userId = ((CustomUserDetails) user).getId();
//        quizService.submitAnswer(userId, req.getQuestionId(), req.getOptionId());
//        return ResponseEntity.ok("Saved");
//    }
    @GetMapping("/next/{animalId}")
    public Question getNextQuestion(@PathVariable Long animalId, Authentication auth) {

        User user = (User) auth.getPrincipal(); // or load from DB by email
        return quizService.getNextQuestion(user, animalId);
    }

    // Submit answer
    @PostMapping("/answer")
    public String submitAnswer(
            @RequestParam Long questionId,
            @RequestParam Long optionId,
            Authentication auth
    ) {
        User user = (User) auth.getPrincipal();
        quizService.submitAnswer(user, questionId, optionId);
        return "Answer saved";
    }
}