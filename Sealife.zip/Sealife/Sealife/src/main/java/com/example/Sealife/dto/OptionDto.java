package com.example.Sealife.dto;

import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class OptionDto {
    private Long id;
    private String text;
}