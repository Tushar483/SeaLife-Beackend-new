package com.example.Sealife.dto;

import com.example.Sealife.domain.Option;
import com.example.Sealife.domain.Question;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.stream.Collectors;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class QuestionDto {
    private Long id;
    private String question;
    private List<OptionDto> options;

    public static QuestionDto from(Question q, List<Option> opts) {
        List<OptionDto> optionDtos = opts.stream()
                .map(o -> new OptionDto(o.getId(), o.getOptionText()))
                .collect(Collectors.toList());

        return new QuestionDto(q.getId(), q.getQuestionText(), optionDtos);
    }
}
