package com.example.Sealife.repository;

import com.example.Sealife.domain.OceanAnimals;
import com.example.Sealife.domain.User;
import com.example.Sealife.domain.UserQuizProgress;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface UserQuizProgressRepository extends JpaRepository<UserQuizProgress, Long> {
    Optional<UserQuizProgress> findByUserAndAnimal(User user, OceanAnimals animal);
    Optional<UserQuizProgress> findByUserIdAndAnimalId(Long userId, Long animalId);

}
