package com.example.Sealife.repository;

import com.example.Sealife.domain.Question;
import com.example.Sealife.domain.User;
import com.example.Sealife.domain.UserAnswer;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface UserAnswerRepository extends JpaRepository<UserAnswer, Long> {

    Optional<UserAnswer> findByUserAndQuestion(User user, Question question);
}
