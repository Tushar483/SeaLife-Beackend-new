package com.example.Sealife.repository;

import com.example.Sealife.domain.OceanAnimals;
import com.example.Sealife.domain.Question;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface QuestionRepository extends JpaRepository<Question, Long> {
    List<Question> findByAnimalIdOrderByQuestionOrder(Long animalId);
    List<Question> findByAnimalOrderByQuestionOrder(OceanAnimals animal);
    List<Question> findByAnimalId(Long animalId);
}
