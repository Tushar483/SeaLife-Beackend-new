package com.example.Sealife.repository;

import com.example.Sealife.domain.Option;
import com.example.Sealife.domain.Question;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface OptionRepository extends JpaRepository<Option, Long> {
    List<Option> findByQuestionId(Long questionId);
    List<Option> findByQuestion(Question question);
}