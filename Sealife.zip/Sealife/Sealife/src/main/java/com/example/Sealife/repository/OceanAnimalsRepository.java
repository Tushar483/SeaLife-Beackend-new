package com.example.Sealife.repository;

import com.example.Sealife.domain.OceanAnimals;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface OceanAnimalsRepository extends JpaRepository<OceanAnimals, Long> {

    Optional<OceanAnimals> findByNameIgnoreCase(String name);
}