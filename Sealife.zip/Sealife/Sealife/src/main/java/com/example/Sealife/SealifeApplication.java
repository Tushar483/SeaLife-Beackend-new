package com.example.Sealife;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SealifeApplication {

	public static void main(String[] args) {
		SpringApplication.run(SealifeApplication.class, args);
	}

}
